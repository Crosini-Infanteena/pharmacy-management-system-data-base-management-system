import java.util.*;

public class NotesAndTodoManager {
    static Scanner scanner = new Scanner(System.in);
    static List<String> notes = new ArrayList<>();
    static List<String> todos = new ArrayList<>();
    static List<Boolean> todoStatus = new ArrayList<>();

    public static NotesAndTodoManager(String[] args) {
        while (true) {
            System.out.println("\n--- Notes & To-Do Menu ---");
            System.out.println("1. Add Note");
            System.out.println("2. View Notes");
            System.out.println("3. Add To-Do");
            System.out.println("4. View To-Dos");
            System.out.println("5. Mark To-Do Complete/Incomplete");
            System.out.println("6. Edit Note");
            System.out.println("7. Edit To-Do");
            System.out.println("8. Delete Note");
            System.out.println("9. Delete To-Do");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt(); scanner.nextLine();

            switch (choice) {
                case 1 -> addNote();
                case 2 -> viewNotes();
                case 3 -> addTodo();
                case 4 -> viewTodos();
                case 5 -> toggleTodoStatus();
                case 6 -> editNote();
                case 7 -> editTodo();
                case 8 -> deleteNote();
                case 9 -> deleteTodo();
                case 0 -> System.exit(0);
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    static void addNote() {
        System.out.print("Enter note: ");
        String note = scanner.nextLine();
        notes.add(note);
    }

    static void viewNotes() {
        System.out.println("\n--- Notes ---");
        for (int i = 0; i < notes.size(); i++) {
            System.out.println((i + 1) + ". " + notes.get(i));
        }
    }

    static void addTodo() {
        System.out.print("Enter to-do item: ");
        String todo = scanner.nextLine();
        todos.add(todo);
        todoStatus.add(false);
    }

    static void viewTodos() {
        System.out.println("\n--- To-Do List ---");
        for (int i = 0; i < todos.size(); i++) {
            String status = todoStatus.get(i) ? "[Done]" : "[Pending]";
            System.out.println((i + 1) + ". " + status + " " + todos.get(i));
        }
    }

    static void toggleTodoStatus() {
        viewTodos();
        System.out.print("Enter to-do number to toggle status: ");
        int idx = scanner.nextInt(); scanner.nextLine();
        if (idx >= 1 && idx <= todoStatus.size()) {
            todoStatus.set(idx - 1, !todoStatus.get(idx - 1));
        } else {
            System.out.println("Invalid number.");
        }
    }

    static void editNote() {
        viewNotes();
        System.out.print("Enter note number to edit: ");
        int idx = scanner.nextInt(); scanner.nextLine();
        if (idx >= 1 && idx <= notes.size()) {
            System.out.print("Enter new content: ");
            notes.set(idx - 1, scanner.nextLine());
        } else {
            System.out.println("Invalid number.");
        }
    }

    static void editTodo() {
        viewTodos();
        System.out.print("Enter to-do number to edit: ");
        int idx = scanner.nextInt(); scanner.nextLine();
        if (idx >= 1 && idx <= todos.size()) {
            System.out.print("Enter new content: ");
            todos.set(idx - 1, scanner.nextLine());
        } else {
            System.out.println("Invalid number.");
        }
    }

    static void deleteNote() {
        viewNotes();
        System.out.print("Enter note number to delete: ");
        int idx = scanner.nextInt(); scanner.nextLine();
        if (idx >= 1 && idx <= notes.size()) {
            notes.remove(idx - 1);
        } else {
            System.out.println("Invalid number.");
        }
    }

    static void deleteTodo() {
        viewTodos();
        System.out.print("Enter to-do number to delete: ");
        int idx = scanner.nextInt(); scanner.nextLine();
        if (idx >= 1 && idx <= todos.size()) {
            todos.remove(idx - 1);
            todoStatus.remove(idx - 1);
        } else {
            System.out.println("Invalid number.");
        }
    }
}