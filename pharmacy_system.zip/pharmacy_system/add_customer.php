<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Customer</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-image: url('images/customer_background.jpg'); /* your image path */
      background-size: cover;
      background-position: center;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: white;
    }

    .form-container {
      background-color: rgba(0, 0, 0, 0.7); /* dark transparent background */
      padding: 30px;
      border-radius: 10px;
      width: 400px;
    }

    .form-container h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    .form-container input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border-radius: 5px;
      border: none;
    }

    .form-container input[type="submit"] {
      background-color: #28a745;
      color: white;
      cursor: pointer;
    }

    .form-container input[type="submit"]:hover {
      background-color: #218838;
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h2>Add Customer</h2>
    <form action="save_customer.php" method="POST">
      <label for="name">Customer Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="phone">Phone:</label>
      <input type="text" id="phone" name="phone" required>

      <label for="address">Address:</label>
      <input type="text" id="address" name="address" required>

      <input type="submit" value="Save Customer">
    </form>
  </div>

</body>
</html>

