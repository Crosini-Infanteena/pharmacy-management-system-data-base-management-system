<?php
include 'db.php';

// Fetch customers and medicines
$customers = $conn->query("SELECT * FROM customers");
$medicines = $conn->query("SELECT * FROM medicines");
?>

<h2>Add Prescription</h2>
<form method="POST" action="save_prescription.php">
    <label>Customer:</label><br>
    <select name="customer_id" required>
        <?php while ($c = $customers->fetch_assoc()): ?>
            <option value="<?= $c['id'] ?>"><?= $c['name'] ?></option>
        <?php endwhile; ?>
    </select><br><br>

    <label>Medicine:</label><br>
    <select name="medicine_id" required>
        <?php while ($m = $medicines->fetch_assoc()): ?>
            <option value="<?= $m['id'] ?>"><?= $m['name'] ?></option>
        <?php endwhile; ?>
    </select><br><br>

    <label>Dosage Instructions:</label><br>
    <textarea name="instructions" required></textarea><br><br>

    <input type="submit" value="Save Prescription">
</form>
