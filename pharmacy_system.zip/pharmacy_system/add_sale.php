<?php
include 'db.php'; // Include the database connection

// Fetch customers and medicines to display in drop-downs
$customers_query = "SELECT id, name FROM customers";
$customers_result = mysqli_query($conn, $customers_query);

$medicines_query = "SELECT id, name FROM medicines";
$medicines_result = mysqli_query($conn, $medicines_query);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture form data after submission
    $customer_id = $_POST['customer_id'];
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];
    $total_price = $_POST['total_price'];

    // Insert sale into the sales table
    $query = "INSERT INTO sales (customer_id, medicine_id, quantity, total_price, sale_date) 
              VALUES ('$customer_id', '$medicine_id', '$quantity', '$total_price', NOW())";

    // Execute the query
    $result = mysqli_query($conn, $query);

    // Check for success
    if ($result) {
        echo "Sale added successfully!";
    } else {
        // If error, display the error message
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Sale</title>
   <style>
    body {
        background-image: url('images/sale_background.jpg'); /* Use your new image here */
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        font-family: Arial, sans-serif;
        color: white;
    }

    h1 {
        text-align: center;
        margin-top: 50px;
        color: #fff;
    }

    form {
        margin: 50px auto;
        width: 60%;
        background-color: rgba(0, 0, 0, 0.6);
        padding: 30px;
        border-radius: 10px;
        color: #fff;
    }

    label, input, select {
        display: block;
        width: 100%;
        margin: 10px 0;
        padding: 10px;
        font-size: 16px;
        border-radius: 5px;
    }

    input[type="number"], input[type="text"], select {
        background-color: #333;
        color: #fff;
        border: 1px solid #ccc;
    }

    button {
        width: 100%;
        padding: 10px;
        font-size: 18px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button:hover {
        background-color: #45a049;
    }
</style>

</head>
<body>

    <h1>Add Sale</h1>

    <!-- Form for adding sale -->
    <form method="POST" action="add_sale.php">
        <label for="customer_id">Customer:</label>
        <select name="customer_id" id="customer_id">
            <option value="">Select Customer</option>
            <?php while ($customer = mysqli_fetch_assoc($customers_result)): ?>
                <option value="<?php echo $customer['id']; ?>"><?php echo $customer['name']; ?></option>
            <?php endwhile; ?>
        </select>
        <br><br>

        <label for="medicine_id">Medicine:</label>
        <select name="medicine_id" id="medicine_id">
            <option value="">Select Medicine</option>
            <?php while ($medicine = mysqli_fetch_assoc($medicines_result)): ?>
                <option value="<?php echo $medicine['id']; ?>"><?php echo $medicine['name']; ?></option>
            <?php endwhile; ?>
        </select>
        <br><br>

        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" id="quantity" required>
        <br><br>

        <label for="total_price">Total Price:</label>
        <input type="text" name="total_price" id="total_price" required>
        <br><br>

        <button type="submit">Add Sale</button>
    </form>

</body>
</html>
