<?php
include 'db.php';

// Check if the 'id' is set in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete sales records related to the medicine
    $deleteSales = "DELETE FROM sales WHERE medicine_id = $id";
    mysqli_query($conn, $deleteSales);

    // Now delete the medicine
    $sql = "DELETE FROM medicines WHERE id = $id";

    if (mysqli_query($conn, $sql)) {
        echo "Medicine deleted successfully. <a href='view_medicines.php'>View Medicines</a>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "No medicine ID specified.";
}
?>
