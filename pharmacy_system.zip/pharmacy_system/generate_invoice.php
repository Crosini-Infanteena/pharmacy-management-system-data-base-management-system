<?php
if (!isset($_GET['sale_id'])) {
    die("Sale ID is missing in the URL.");
}
$sale_id = $_GET['sale_id'];
if (!is_numeric($sale_id)) {
    die("Invalid Sale ID.");
}
?>
<?php
include 'db.php';

$sale_id = $_GET['sale_id'];

$sql = "SELECT s.id, s.quantity, s.total_price, s.created_at,
               c.name AS customer_name, c.phone, c.address,
               m.name AS medicine_name, m.price AS unit_price
        FROM sales s
        JOIN customers c ON s.customer_id = c.id
        JOIN medicines m ON s.medicine_id = m.id
        WHERE s.id = $sale_id";

$result = $conn->query($sql);

// Check if no result is found
if ($result->num_rows === 0) {
    die("No sale found with ID: " . $sale_id);
}

// If sale is found, fetch the data
$sale = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
</head>
<body>
    <h2>Pharmacy Invoice</h2>
    <hr>
    <p><strong>Date:</strong> <?= $sale['created_at'] ?></p>
    <p><strong>Invoice #:</strong> <?= $sale['id'] ?></p>
    <hr>
    <h3>Customer Details</h3>
    <p><strong>Name:</strong> <?= $sale['customer_name'] ?><br>
       <strong>Phone:</strong> <?= $sale['phone'] ?><br>
       <strong>Address:</strong> <?= $sale['address'] ?></p>

    <h3>Sale Details</h3>
    <table border="1" cellpadding="10">
        <tr>
            <th>Medicine</th>
            <th>Unit Price</th>
            <th>Qty</th>
            <th>Total</th>
        </tr>
        <tr>
            <td><?= $sale['medicine_name'] ?></td>
            <td><?= number_format($sale['unit_price'], 2) ?></td>
            <td><?= $sale['quantity'] ?></td>
            <td><?= number_format($sale['total_price'], 2) ?></td>
        </tr>
    </table>

    <h3>Total: <?= number_format($sale['total_price'], 2) ?></h3>
    <br>
    <button onclick="window.print()">Print Invoice</button>
</body>
</html>
