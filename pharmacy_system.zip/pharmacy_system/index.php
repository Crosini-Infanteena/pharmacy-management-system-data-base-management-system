<!DOCTYPE html>
<html>
<head>
    <title>Pharmacy Management System</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-image: url('images/background.jpg'); /* Your background image */
            background-size: cover;
            background-position: center;
            height: 100vh;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .welcome-box {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            width: 70%;
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 15px;
        }

        p {
            font-size: 1.2em;
            margin-bottom: 30px;
        }

        .menu {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
        }

        .menu a {
            display: inline-block;
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 1em;
        }

        .menu a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="welcome-box">
        <h1>Welcome to the Pharmacy Management System</h1>
        <p>Select an option from the menu to get started.</p>
        <div class="menu">
            <a href="add_medicine.php">Add Medicine</a>
            <a href="view_medicines.php">View Medicines</a>
            <a href="add_customer.php">Add Customer</a>
            <a href="view_customers.php">View Customers</a>
            <a href="add_sale.php">Add Sale</a>
            <a href="view_sales.php">View Sales</a>
        </div>
    </div>
</body>
</html>
