<?php
include 'db.php';

$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];

$sql = "INSERT INTO customers (name, phone, address) 
        VALUES ('$name', '$phone', '$address')";

if ($conn->query($sql) === TRUE) {
    echo "Customer added successfully. <a href='view_customers.php'>View All</a>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
