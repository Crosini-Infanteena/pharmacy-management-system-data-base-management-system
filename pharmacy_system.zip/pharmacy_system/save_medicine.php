<?php
include 'db.php';

$name = $_POST['name'] ?? '';
$type = $_POST['type'] ?? '';
$price = $_POST['price'] ?? '';
$quantity = $_POST['quantity'] ?? '';
$sql = "INSERT INTO medicines (name, type, price, quantity) 
        VALUES ('$name', '$type', '$price', '$quantity')";

if ($conn->query($sql) === TRUE) {
    echo "Medicine added successfully. <a href='view_medicines.php'>View All</a>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>

