<?php
include 'db.php';

$customer_id = $_POST['customer_id'];
$medicine_id = $_POST['medicine_id'];
$instructions = $_POST['instructions'];

$sql = "INSERT INTO prescriptions (customer_id, medicine_id, instructions) 
        VALUES ('$customer_id', '$medicine_id', '$instructions')";

if ($conn->query($sql) === TRUE) {
    echo "Prescription saved successfully. <a href='view_prescriptions.php'>View All</a>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
