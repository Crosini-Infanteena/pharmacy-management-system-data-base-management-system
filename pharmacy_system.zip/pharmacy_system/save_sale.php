<?php
include 'db.php';

$customer_id = $_POST['customer_id'];
$medicine_id = $_POST['medicine_id'];
$quantity = $_POST['quantity'];

// Get medicine price
$medicine = $conn->query("SELECT * FROM medicines WHERE id = $medicine_id")->fetch_assoc();
$price = $medicine['price'];
$total_price = $price * $quantity;

// Check stock
if ($medicine['quantity'] < $quantity) {
    echo "Insufficient stock. <a href='add_sale.php'>Try again</a>";
    exit;
}

// Insert sale
$sql = "INSERT INTO sales (customer_id, medicine_id, quantity, total_price) 
        VALUES ('$customer_id', '$medicine_id', '$quantity', '$total_price')";

if ($conn->query($sql) === TRUE) {
    // Update stock
    $new_qty = $medicine['quantity'] - $quantity;
    $conn->query("UPDATE medicines SET quantity = $new_qty WHERE id = $medicine_id");

    echo "Sale recorded. <a href='view_sales.php'>View Sales</a> | <a href='generate_invoice.php?sale_id=" . $conn->insert_id . "'>Print Invoice</a>";
} else {
    echo "Error: " . $conn->error;
}
?>
