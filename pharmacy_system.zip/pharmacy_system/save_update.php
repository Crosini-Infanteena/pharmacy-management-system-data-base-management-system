<?php
include 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$type = $_POST['type'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];

$sql = "UPDATE medicines SET 
        name='$name', type='$type', price='$price', quantity='$quantity' 
        WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Medicine updated. <a href='view_medicines.php'>Back to list</a>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
