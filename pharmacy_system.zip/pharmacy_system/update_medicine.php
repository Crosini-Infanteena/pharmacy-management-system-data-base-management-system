<!DOCTYPE html>
<html>
<head>
    <title>View Medicines</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-image: url('images/background.jpg');
            background-size: cover;
            background-position: center;
            color: white;
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7);
            margin: 50px auto;
            padding: 30px;
            width: 80%;
            border-radius: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            color: black;
        }

        table, th, td {
            border: 1px solid black;
            padding: 10px;
        }

        th {
            background-color: #3f51b5;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Available Medicines</h2>
        <!-- Your medicine table code starts here -->
        <?php
        include 'db.php';
        $result = mysqli_query($conn, "SELECT * FROM medicines");

        echo "<table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Quantity</th>
                </tr>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['type']}</td>
                    <td>{$row['price']}</td>
                    <td>{$row['quantity']}</td>
                  </tr>";
        }

        echo "</table>";
        ?>
    </div>
</body>
</html>
