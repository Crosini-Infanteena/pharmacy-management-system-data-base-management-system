<?php
include 'db.php';

// Fetch all customers from the database
$result = mysqli_query($conn, "SELECT * FROM customers");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Customers</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url('images/view_customers_bg.jpg');
      background-size: cover;
      background-position: center;
      padding: 20px;
      color: #333;
    }

    .container {
      background-color: rgba(255, 255, 255, 0.8);
      padding: 20px;
      border-radius: 8px;
      width: 80%;
      margin: 0 auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background-color: white;
    }

    th, td {
      padding: 10px;
      border: 1px solid #ccc;
    }

    th {
      background-color: #333;
      color: white;
    }

    h2 {
      text-align: center;
      color: #333;
    }
  </style>
</head>
<body>
<div class="container">
  <h2>Customers List</h2>

  <?php if (mysqli_num_rows($result) > 0): ?>
  <table>
    <tr>
      <th>#</th> <!-- Sequential number instead of database ID -->
      <th>Name</th>
      <th>Phone</th>
      <th>Address</th>
    </tr>
    <?php 
      $serial = 1;
      while ($row = mysqli_fetch_assoc($result)): 
    ?>
    <tr>
      <td><?= $serial++ ?></td> <!-- This will show 1, 2, 3, ... -->
      <td><?= $row['name'] ?></td>
      <td><?= $row['phone'] ?></td>
      <td><?= $row['address'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
  <?php else: ?>
    <p>No customers found.</p>
  <?php endif; ?>
</div>
</body>
</html>
