<?php
include 'db.php';

// Fetch all medicines
$result = mysqli_query($conn, "SELECT * FROM medicines");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Medicines</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url('images/view_medicines_bg.jpg');
      background-size: cover;
      background-position: center;
      padding: 20px;
      color: #333;
    }

    .container {
      background-color: rgba(255, 255, 255, 0.9);
      padding: 20px;
      border-radius: 8px;
      width: 90%;
      margin: 0 auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background-color: white;
    }

    th, td {
      padding: 10px;
      border: 1px solid #ccc;
    }

    th {
      background-color: #333;
      color: white;
    }

    .btn {
      padding: 5px 10px;
      text-decoration: none;
      border-radius: 5px;
      font-size: 14px;
    }

    .btn-delete {
      background-color: #d9534f;
      color: white;
    }

    .btn-back {
      background-color: #5bc0de;
      color: white;
      margin-bottom: 10px;
      display: inline-block;
    }

    h2 {
      text-align: center;
    }
  </style>
</head>
<body>
<div class="container">
  <a href="index.php" class="btn btn-back">← Back</a>
  <h2>Medicines List</h2>
  <?php if (mysqli_num_rows($result) > 0): ?>
  <table>
    <tr>
      <th>#</th>
      <th>Name</th>
      <th>Type</th>
      <th>Price</th>
      <th>Quantity</th>
      <th>Actions</th>
    </tr>
    <?php 
      $serial = 1;
      while ($row = mysqli_fetch_assoc($result)): 
    ?>
    <tr>
      <td><?= $serial++ ?></td>
      <td><?= $row['name'] ?></td>
      <td><?= $row['type'] ?></td>
      <td><?= $row['price'] ?></td>
      <td><?= $row['quantity'] ?></td>
      <td>
        <a href="delete_medicine.php?id=<?= $row['id'] ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this medicine?');">Delete</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
  <?php else: ?>
    <p>No medicines found.</p>
  <?php endif; ?>
</div>
</body>
</html>
