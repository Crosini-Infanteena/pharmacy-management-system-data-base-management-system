<?php
include 'db.php';
$sql = "SELECT p.id, c.name AS customer_name, m.name AS medicine_name, p.instructions
        FROM prescriptions p
        JOIN customers c ON p.customer_id = c.id
        JOIN medicines m ON p.medicine_id = m.id";
$result = $conn->query($sql);
?>

<h2>Prescriptions</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th><th>Customer</th><th>Medicine</th><th>Instructions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['customer_name'] ?></td>
        <td><?= $row['medicine_name'] ?></td>
        <td><?= $row['instructions'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>
