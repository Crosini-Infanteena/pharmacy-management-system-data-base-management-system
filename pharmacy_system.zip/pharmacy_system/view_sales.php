<?php
include 'db.php';

// Fetch sales with customer and medicine names
$sql = "SELECT s.*, c.name AS customer_name, m.name AS medicine_name 
        FROM sales s
        JOIN customers c ON s.customer_id = c.id
        JOIN medicines m ON s.medicine_id = m.id";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Sales</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url('images/view_sales_bg.jpg');
      background-size: cover;
      background-position: center;
      padding: 20px;
      color: #333;
    }

    .container {
      background-color: rgba(255, 255, 255, 0.9);
      padding: 20px;
      border-radius: 8px;
      width: 90%;
      margin: 0 auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background-color: white;
    }

    th, td {
      padding: 10px;
      border: 1px solid #ccc;
    }

    th {
      background-color: #333;
      color: white;
    }

    h2 {
      text-align: center;
    }
  </style>
</head>
<body>
<div class="container">
  <h2>Sales List</h2>
  <?php if (mysqli_num_rows($result) > 0): ?>
  <table>
    <tr>
      <th>#</th>
      <th>Customer</th>
      <th>Medicine</th>
      <th>Quantity</th>
      <th>Total</th>
      <th>Date</th>
    </tr>
    <?php 
      $serial = 1;
      while ($row = mysqli_fetch_assoc($result)): 
    ?>
    <tr>
      <td><?= $serial++ ?></td>
      <td><?= $row['customer_name'] ?></td>
      <td><?= $row['medicine_name'] ?></td>
      <td><?= $row['quantity'] ?></td>
      <td><?= $row['total_price'] ?></td>
      <td><?= $row['sale_date'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
  <?php else: ?>
    <p>No sales records found.</p>
  <?php endif; ?>
</div>
</body>
</html>
